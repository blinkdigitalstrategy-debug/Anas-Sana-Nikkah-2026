Wedding invitation website

Open index.html in a browser to preview the invitation.

Editable text and links:
- Most wedding details are near the top of script.js in the invitationData object.
- Page text and image order can be edited directly in index.html.
- Colors, spacing, and animations are in styles.css.

Files to upload/share as a website:
- index.html
- styles.css
- script.js
- the assets folder

For WhatsApp previews, upload this folder to a public HTTPS host. WhatsApp can then read the Open Graph title, description, and preview image from index.html.
