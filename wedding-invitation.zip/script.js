const invitationData = {
  groomName: "Anas Faisal",
  brideName: "Sana Farhin",
  weddingDateISO: "2026-06-07T12:00:00+05:30",
  dateText: "07th June 2026",
  timeText: "12.00 PM",
  venueName: "Blue Diamond Auditorium",
  venueAddress: "Mala, Koottanad Edappal Road",
  mapUrl: "https://maps.app.goo.gl/EUGyjhGbHncMKoHY6",
  invitationMessage:
    "As we begin this beautiful journey together, we warmly invite you and your family to share in our happiness, bless our nikah celebration, and make the day unforgettable with your presence."
};

const cover = document.querySelector("#cover");
const openInvite = document.querySelector("#openInvite");
const musicToggle = document.querySelector("#musicToggle");
const bgMusic = document.querySelector("#bgMusic");

document.querySelectorAll("[data-edit]").forEach((node) => {
  const key = node.dataset.edit;
  if (invitationData[key]) node.textContent = invitationData[key];
});

function openInvitation() {
  cover.classList.add("is-open");
  document.body.classList.add("invite-open");
  bgMusic.volume = 1;
  bgMusic.load();
  bgMusic.play().then(() => {
    musicToggle.classList.add("is-playing");
    musicToggle.setAttribute("aria-label", "Pause background music");
  }).catch(() => {
    musicToggle.setAttribute("aria-label", "Play background music");
  });
}

openInvite.addEventListener("click", openInvitation);

musicToggle.addEventListener("click", async () => {
  if (bgMusic.paused) {
    await bgMusic.play();
    musicToggle.classList.add("is-playing");
    musicToggle.setAttribute("aria-label", "Pause background music");
  } else {
    bgMusic.pause();
    musicToggle.classList.remove("is-playing");
    musicToggle.setAttribute("aria-label", "Play background music");
  }
});

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) entry.target.classList.add("is-visible");
  });
}, { threshold: 0.16 });

document.querySelectorAll(".reveal").forEach((node) => revealObserver.observe(node));

const countdownNodes = [...document.querySelectorAll("#countdown strong")];
const weddingDate = new Date(invitationData.weddingDateISO);

function updateCountdown() {
  const remaining = Math.max(0, weddingDate - new Date());
  const seconds = Math.floor(remaining / 1000);
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  [days, hours, minutes, secs].forEach((value, index) => {
    countdownNodes[index].textContent = String(value).padStart(2, "0");
  });
}

updateCountdown();
setInterval(updateCountdown, 1000);

const scratchCard = document.querySelector("#scratchCard");
const scratchCanvas = document.querySelector("#scratchCanvas");
const scratchCtx = scratchCanvas.getContext("2d", { willReadFrequently: true });
const petalField = document.querySelector("#petalField");
let scratched = false;
let isDrawing = false;

function resizeScratch() {
  const rect = scratchCard.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  scratchCanvas.width = rect.width * ratio;
  scratchCanvas.height = rect.height * ratio;
  scratchCtx.setTransform(ratio, 0, 0, ratio, 0, 0);
  if (scratched) {
    scratchCtx.clearRect(0, 0, rect.width, rect.height);
    return;
  }
  paintScratchLayer(rect.width, rect.height);
}

function paintScratchLayer(width, height) {
  const gradient = scratchCtx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, "#8f6b28");
  gradient.addColorStop(0.36, "#f5d77f");
  gradient.addColorStop(0.7, "#aa792a");
  gradient.addColorStop(1, "#f9e7a9");
  scratchCtx.globalCompositeOperation = "source-over";
  scratchCtx.fillStyle = gradient;
  scratchCtx.fillRect(0, 0, width, height);
  scratchCtx.fillStyle = "rgba(255,255,255,0.18)";
  for (let x = -height; x < width; x += 34) {
    scratchCtx.beginPath();
    scratchCtx.moveTo(x, height);
    scratchCtx.lineTo(x + height, 0);
    scratchCtx.lineTo(x + height + 14, 0);
    scratchCtx.lineTo(x + 14, height);
    scratchCtx.closePath();
    scratchCtx.fill();
  }
}

function scratchAt(clientX, clientY) {
  const rect = scratchCanvas.getBoundingClientRect();
  const x = clientX - rect.left;
  const y = clientY - rect.top;
  scratchCtx.globalCompositeOperation = "destination-out";
  scratchCtx.beginPath();
  scratchCtx.arc(x, y, 26, 0, Math.PI * 2);
  scratchCtx.fill();
}

function revealIfReady() {
  if (scratched) return;
  const { width, height } = scratchCanvas;
  const pixels = scratchCtx.getImageData(0, 0, width, height).data;
  let transparent = 0;
  for (let i = 3; i < pixels.length; i += 28) {
    if (pixels[i] < 60) transparent += 1;
  }
  if (transparent / (pixels.length / 28) > 0.42) {
    scratched = true;
    scratchCard.classList.add("is-revealed");
    scratchCtx.clearRect(0, 0, width, height);
    popPetals();
  }
}

function pointerPosition(event) {
  const point = event.touches ? event.touches[0] : event;
  return { x: point.clientX, y: point.clientY };
}

scratchCanvas.addEventListener("pointerdown", (event) => {
  isDrawing = true;
  scratchCanvas.setPointerCapture(event.pointerId);
  scratchAt(event.clientX, event.clientY);
});

scratchCanvas.addEventListener("pointermove", (event) => {
  if (!isDrawing) return;
  scratchAt(event.clientX, event.clientY);
});

scratchCanvas.addEventListener("pointerup", () => {
  isDrawing = false;
  revealIfReady();
});

scratchCanvas.addEventListener("pointerleave", () => {
  if (isDrawing) revealIfReady();
  isDrawing = false;
});

scratchCanvas.addEventListener("touchmove", (event) => {
  event.preventDefault();
  const point = pointerPosition(event);
  scratchAt(point.x, point.y);
}, { passive: false });

function popPetals() {
  for (let i = 0; i < 34; i += 1) {
    const petal = document.createElement("span");
    const angle = Math.random() * Math.PI * 2;
    const distance = 90 + Math.random() * 190;
    petal.className = "petal";
    petal.style.setProperty("--x", `${Math.cos(angle) * distance}px`);
    petal.style.setProperty("--y", `${Math.sin(angle) * distance - 80}px`);
    petal.style.setProperty("--r", `${Math.random() * 520 - 260}deg`);
    petal.style.animationDelay = `${Math.random() * 0.18}s`;
    petalField.appendChild(petal);
    setTimeout(() => petal.remove(), 2200);
  }
}

window.addEventListener("resize", resizeScratch);
resizeScratch();
